-- MySQL dump 10.11
--
-- Host: localhost    Database: hackwars
-- ------------------------------------------------------
-- Server version	5.0.67-0ubuntu6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `hackwars`
--

/*!40000 DROP DATABASE IF EXISTS `hackwars`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `hackwars` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `hackwars`;

--
-- Table structure for table `apis`
--

DROP TABLE IF EXISTS `apis`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `apis` (
  `num` int(11) NOT NULL auto_increment,
  `name` varchar(150) NOT NULL default '',
  `call` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `parameters` tinytext NOT NULL,
  `returnvalues` tinytext NOT NULL,
  `level` int(11) NOT NULL default '0',
  `leveltype` enum('Banking','Attack','FTP','Watch','Total') NOT NULL default 'Banking',
  `cpucost` float NOT NULL default '0',
  `compilingcost` float NOT NULL default '0',
  `example` text NOT NULL,
  `type` enum('Banking','Attack','FTP','Watch','Challenge','Other') NOT NULL default 'Banking',
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `attached_networks`
--

DROP TABLE IF EXISTS `attached_networks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `attached_networks` (
  `network_id` int(10) unsigned NOT NULL,
  `attached_network_id` int(10) unsigned NOT NULL,
  `entranceMessage` varchar(300) NOT NULL default '',
  PRIMARY KEY  (`network_id`,`attached_network_id`),
  KEY `FK_attached_networks_2` (`attached_network_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `bookmarks`
--

DROP TABLE IF EXISTS `bookmarks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bookmarks` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `domain` varchar(60) NOT NULL,
  `name` varchar(255) NOT NULL,
  `folder` varchar(50) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `challenges`
--

DROP TABLE IF EXISTS `challenges`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `challenges` (
  `num` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `description` text NOT NULL,
  `inputs` text NOT NULL,
  `outputs` text NOT NULL,
  `level` int(11) NOT NULL default '0',
  `leveltype` enum('Banking','Attack','FTP','Watch','Total','Scan') NOT NULL default 'Banking',
  `experience` float NOT NULL default '0',
  `money` float NOT NULL default '0',
  `inputtype` enum('String','Double','Int') NOT NULL default 'String',
  `outputtype` enum('String','Double','Int') NOT NULL,
  `clue` enum('0','1') NOT NULL default '0',
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `client` (
  `clientdate` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `domains`
--

DROP TABLE IF EXISTS `domains`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `domains` (
  `num` int(11) NOT NULL auto_increment,
  `ip` varchar(20) NOT NULL,
  `domain` varchar(75) NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `domainsearch`
--

DROP TABLE IF EXISTS `domainsearch`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `domainsearch` (
  `num` int(11) NOT NULL auto_increment,
  `domain` varchar(40) NOT NULL,
  `timeout` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `uid` int(11) NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `drop_table`
--

DROP TABLE IF EXISTS `drop_table`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `drop_table` (
  `drop_id` int(11) default NULL,
  `item_id` int(11) default NULL,
  `weight` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `facebook`
--

DROP TABLE IF EXISTS `facebook`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `facebook` (
  `num` int(11) NOT NULL auto_increment,
  `to` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `message` text NOT NULL,
  `date` bigint(20) NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `facebook_bank`
--

DROP TABLE IF EXISTS `facebook_bank`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `facebook_bank` (
  `num` bigint(20) NOT NULL auto_increment,
  `id` bigint(20) NOT NULL,
  `petty` double NOT NULL,
  `bank` double NOT NULL,
  `port` smallint(6) NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `items` (
  `id` int(11) NOT NULL auto_increment,
  `data` mediumblob,
  `description` char(128) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `network`
--

DROP TABLE IF EXISTS `network`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `network` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `storeNPC` varchar(45) NOT NULL default '',
  `attack_probability` float NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `network_npc`
--

DROP TABLE IF EXISTS `network_npc`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `network_npc` (
  `network_id` int(10) unsigned NOT NULL,
  `npc_ip` varchar(45) NOT NULL,
  `npc_type` enum('attack','quest','mining','store') NOT NULL default 'attack',
  `resource` enum('Duct Tape','Germanium','Silicon','YBCO','Plutonium') NOT NULL,
  `name` varchar(45) NOT NULL default '',
  `title` varchar(45) NOT NULL default '',
  PRIMARY KEY  (`network_id`,`npc_ip`,`npc_type`),
  CONSTRAINT `FK_network_npc_1` FOREIGN KEY (`network_id`) REFERENCES `network` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `newtutorials`
--

DROP TABLE IF EXISTS `newtutorials`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `newtutorials` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `tutorial` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `sounds`
--

DROP TABLE IF EXISTS `sounds`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sounds` (
  `num` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `file` varchar(100) NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `stats`
--

DROP TABLE IF EXISTS `stats`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stats` (
  `num` int(11) NOT NULL auto_increment,
  `ip` varchar(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `wealth` double NOT NULL,
  `attackxp` double NOT NULL,
  `merchantingxp` double NOT NULL,
  `firewallxp` double NOT NULL,
  `watchxp` double NOT NULL,
  `scanxp` double NOT NULL,
  `httpxp` double NOT NULL,
  `hackcount` int(11) NOT NULL,
  `votecount` int(11) NOT NULL,
  `totalxp` double NOT NULL,
  `totallvl` int(11) NOT NULL,
  `redirectxp` double NOT NULL,
  `repairxp` double NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `tutorials`
--

DROP TABLE IF EXISTS `tutorials`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `tutorials` (
  `num` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `out` blob NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user` (
  `ip` char(128) default NULL,
  `stats` mediumblob,
  `num` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`num`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=10172 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-02-05 23:51:25
