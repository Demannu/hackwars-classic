-- MySQL dump 10.11
--
-- Host: localhost    Database: hackerforum
-- ------------------------------------------------------
-- Server version	5.0.45-Debian_1ubuntu3-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `hackerforum`
--

/*!40000 DROP DATABASE IF EXISTS `hackerforum`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `hackerforum` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `hackerforum`;

--
-- Table structure for table `Test`
--

DROP TABLE IF EXISTS `Test`;
CREATE TABLE `Test` (
  `num` int(11) NOT NULL auto_increment,
  UNIQUE KEY `num` (`num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `beta`
--

DROP TABLE IF EXISTS `beta`;
CREATE TABLE `beta` (
  `num` int(11) NOT NULL auto_increment,
  `email` varchar(100) NOT NULL,
  `code` char(8) NOT NULL,
  `taken` enum('Y','N') NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `num` bigint(20) NOT NULL auto_increment,
  `name` varchar(150) NOT NULL default '',
  `description` text NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Table structure for table `challenges`
--

DROP TABLE IF EXISTS `challenges`;
CREATE TABLE `challenges` (
  `num` int(11) NOT NULL auto_increment,
  `ip` varchar(20) NOT NULL,
  `c1` enum('Y','N') NOT NULL default 'N',
  `c2` enum('Y','N') NOT NULL default 'N',
  `c3` enum('Y','N') NOT NULL default 'N',
  `c4` enum('Y','N') NOT NULL default 'N',
  `c5` enum('Y','N') NOT NULL default 'N',
  `c6` enum('Y','N') NOT NULL default 'N',
  `c13` enum('Y','N') NOT NULL default 'N',
  `c14` enum('Y','N') NOT NULL default 'N',
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=6677 DEFAULT CHARSET=latin1;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `num` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `news` text NOT NULL,
  `short` text NOT NULL,
  `datetime` datetime NOT NULL,
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Table structure for table `thread_text`
--

DROP TABLE IF EXISTS `thread_text`;
CREATE TABLE `thread_text` (
  `num` bigint(20) NOT NULL auto_increment,
  `subject` varchar(150) NOT NULL default '',
  `text` text NOT NULL,
  `thread_id` bigint(20) NOT NULL default '0',
  `author` bigint(20) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=409 DEFAULT CHARSET=latin1;

--
-- Table structure for table `threads`
--

DROP TABLE IF EXISTS `threads`;
CREATE TABLE `threads` (
  `num` int(11) NOT NULL auto_increment,
  `name` varchar(150) NOT NULL default '',
  `creator` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `category_id` bigint(20) NOT NULL default '0',
  `lastpost` datetime NOT NULL,
  `lastpostauthor` varchar(15) NOT NULL,
  `sticky` enum('Y','N') NOT NULL default 'N',
  UNIQUE KEY `num` (`num`)
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=latin1;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `num` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `password` varchar(128) NOT NULL default '',
  `email` varchar(150) NOT NULL default '',
  `picture` varchar(128) NOT NULL default '',
  `date_joined` date NOT NULL default '0000-00-00',
  `location` varchar(75) NOT NULL default '',
  `ip` varchar(13) NOT NULL default '',
  `description` text NOT NULL,
  `npc` enum('Y','N') NOT NULL default 'N',
  `last_logged_in` date NOT NULL default '0000-00-00',
  `lastsent` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `facebook_id` bigint(20) NOT NULL default '0',
  `showattack` tinyint(4) NOT NULL default '1',
  `showscan` tinyint(4) NOT NULL default '1',
  `showdetails` tinyint(4) NOT NULL default '1',
  `portcolumns` varchar(25) NOT NULL default '1|1|1|1|1|1|1|1|1|',
  `last_logged_ip` varchar(75) NOT NULL,
  `showtutorial` tinyint(4) NOT NULL default '1',
  UNIQUE KEY `num` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=9642 DEFAULT CHARSET=latin1;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-01-16  0:54:11
